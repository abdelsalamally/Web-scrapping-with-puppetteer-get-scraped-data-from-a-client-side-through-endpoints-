
//const interBank = require('./interbank');

const trust = require('./trust');

(async ()=>{

  
 
    await trust.initialize();



})();